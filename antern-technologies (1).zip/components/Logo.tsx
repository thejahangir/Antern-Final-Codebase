
import React from 'react';

interface LogoProps {
  className?: string;
  showSlogan?: boolean;
  isLight?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ className = "h-10", showSlogan = false, isLight = false }) => {
  return (
    <div className={`flex flex-col ${className}`}>
      <div className="flex items-center gap-2">
        {/* Colorful Blobs/Dots */}
        <div className="flex -space-x-2 relative shrink-0">
          <div className="w-4 h-4 rounded-full bg-[#FFB74D] opacity-90 blur-[0.5px]"></div>
          <div className="w-4 h-4 rounded-full bg-[#FF5252] opacity-80 blur-[0.5px] -translate-y-1"></div>
          <div className="w-4 h-4 rounded-full bg-[#7C4DFF] opacity-90 blur-[0.5px] translate-x-1"></div>
        </div>

        {/* Wordmark */}
        <div className={`text-2xl md:text-3xl font-extrabold tracking-tighter flex items-baseline ${isLight ? 'text-white' : 'text-[#1A1A1A]'}`}>
          <span>ante</span>
          <span className="relative">
            <span className="text-transparent bg-clip-text bg-gradient-to-br from-[#FF5252] via-[#7C4DFF] to-[#FFB74D]">r</span>
          </span>
          <span>n</span>
        </div>
      </div>
      
      {showSlogan && (
        <div className={`text-[10px] md:text-xs font-medium tracking-widest mt-0.5 whitespace-nowrap ${isLight ? 'text-white/60' : 'text-gray-500'}`}>
          BRIGHT THINKING. INTELLIGENT SOLUTIONS.
        </div>
      )}
    </div>
  );
};
